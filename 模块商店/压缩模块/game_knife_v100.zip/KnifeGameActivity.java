package com.gamecenter.app.games.knife;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.gamecenter.app.R;
import com.gamecenter.app.achievement.AchievementManager;
import com.gamecenter.app.achievement.AchievementType;
import com.gamecenter.app.games.GameUsageStore;

import org.json.JSONException;
import org.json.JSONObject;

public class KnifeGameActivity extends AppCompatActivity implements KnifeGameView.OnGameEventListener {

    private static final String TAG = "KnifeGameActivity";
    private static final String GAME_ID = "knife";
    private static final String PREFS_NAME = "knife_game_save";
    private static final String KEY_SAVE_DATA = "save_data";

    private KnifeGameView gameView;
    private GameUsageStore usageStore;
    private AchievementManager achievementManager;

    private SoundPool soundPool;
    private int soundThrow;
    private int soundHit;
    private int soundApple;
    private int soundLevelUp;
    private int soundGameOver;
    private int soundCombo;

    private MediaPlayer bgmPlayer;

    private Vibrator vibrator;
    private boolean soundEnabled = true;
    private boolean vibrationEnabled = true;

    private int currentScore = 0;
    private int currentLevel = 1;
    private int bestScore = 0;
    private int totalGamesPlayed = 0;
    private int totalApplesHit = 0;
    private int maxCombo = 0;
    private int highestLevel = 1;

    private Handler uiHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_knife_game);

        gameView = findViewById(R.id.knife_game_view);
        gameView.setOnGameEventListener(this);

        usageStore = new GameUsageStore(this);
        achievementManager = AchievementManager.getInstance(this);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        loadPersonalStats();
        initSoundPool();
        initBGM();

        if (hasSaveData()) {
            showResumeDialog();
        } else {
            gameView.startGame();
            usageStore.recordLaunch(GAME_ID);
        }

        findViewById(R.id.btn_sound_toggle).setOnClickListener(v -> toggleSound());
        findViewById(R.id.btn_pause).setOnClickListener(v -> togglePause());
        findViewById(R.id.btn_resume).setOnClickListener(v -> togglePause());
        findViewById(R.id.btn_quit).setOnClickListener(v -> {
            saveGameState();
            savePersonalStats();
            finish();
        });
    }

    private void initSoundPool() {
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(audioAttributes)
                .build();

        try {
            soundThrow = soundPool.load(this, R.raw.sound_click_button, 1);
            soundHit = soundPool.load(this, R.raw.sound_win, 1);
            soundApple = soundPool.load(this, R.raw.sound_win, 1);
            soundLevelUp = soundPool.load(this, R.raw.sound_win, 1);
            soundGameOver = soundPool.load(this, R.raw.sound_lose, 1);
            soundCombo = soundPool.load(this, R.raw.sound_win, 1);
        } catch (Exception e) {
            Log.w(TAG, "音效加载失败: " + e.getMessage());
            soundEnabled = false;
        }
    }

    private void initBGM() {
        try {
            bgmPlayer = MediaPlayer.create(this, R.raw.music_gamebg);
            if (bgmPlayer != null) {
                bgmPlayer.setLooping(true);
                bgmPlayer.setVolume(0.3f, 0.3f);
            }
        } catch (Exception e) {
            Log.w(TAG, "背景音乐加载失败: " + e.getMessage());
        }
    }

    private void playSound(int soundId) {
        if (soundEnabled && soundPool != null && soundId != 0) {
            soundPool.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f);
        }
    }

    private void playBGM() {
        if (soundEnabled && bgmPlayer != null && !bgmPlayer.isPlaying()) {
            bgmPlayer.start();
        }
    }

    private void pauseBGM() {
        if (bgmPlayer != null && bgmPlayer.isPlaying()) {
            bgmPlayer.pause();
        }
    }

    private void vibrate(long milliseconds) {
        if (vibrationEnabled && vibrator != null && vibrator.hasVibrator()) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(milliseconds);
            }
        }
    }

    private void toggleSound() {
        soundEnabled = !soundEnabled;
        if (soundEnabled) {
            playBGM();
            Toast.makeText(this, "音效已开启", Toast.LENGTH_SHORT).show();
        } else {
            pauseBGM();
            Toast.makeText(this, "音效已关闭", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPaused = false;

    private void togglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            gameView.pause();
            pauseBGM();
            findViewById(R.id.pause_overlay).setVisibility(View.VISIBLE);
        } else {
            gameView.resume();
            playBGM();
            findViewById(R.id.pause_overlay).setVisibility(View.GONE);
        }
    }

    @Override
    public void onScoreChanged(int score) {
        currentScore = score;
        if (score > bestScore) {
            bestScore = score;
        }
    }

    @Override
    public void onKnivesChanged(int left, int total) {
    }

    @Override
    public void onLevelComplete(int level, int score) {
        currentLevel = level;
        if (level > highestLevel) {
            highestLevel = level;
        }
        playSound(soundLevelUp);
        vibrate(100);
        checkAchievements();
        saveGameState();
    }

    @Override
    public void onGameOver(int score, int level) {
        currentScore = score;
        currentLevel = level;
        totalGamesPlayed++;

        playSound(soundGameOver);
        vibrate(300);

        usageStore.recordScore(GAME_ID, score);
        usageStore.recordPlayTime(GAME_ID, 0);

        if (score >= 100) {
            achievementManager.unlockAchievement(AchievementType.FIRST_WIN);
        }

        checkAchievements();
        clearSaveData();

        uiHandler.postDelayed(() -> {
            if (!isFinishing()) {
                showGameOverStats(score, level);
            }
        }, 1500);
    }

    private void checkAchievements() {
        if (bestScore >= 100) {
            achievementManager.unlockAchievement(AchievementType.FIRST_WIN);
        }
        if (highestLevel >= 3) {
            achievementManager.unlockAchievement(AchievementType.WIN_STREAK_3);
        }
        if (highestLevel >= 5) {
            achievementManager.unlockAchievement(AchievementType.WIN_STREAK_5);
        }
        if (highestLevel >= 10) {
            achievementManager.unlockAchievement(AchievementType.WIN_STREAK_10);
        }
        if (totalGamesPlayed >= 10) {
            achievementManager.unlockAchievement(AchievementType.GAMES_PLAYED_10);
        }
        if (totalGamesPlayed >= 50) {
            achievementManager.unlockAchievement(AchievementType.GAMES_PLAYED_50);
        }
        if (totalGamesPlayed >= 100) {
            achievementManager.unlockAchievement(AchievementType.GAMES_PLAYED_100);
        }
    }

    private void showGameOverStats(int score, int level) {
        String message = String.format("得分: %d\n最高关卡: %d\n历史最高分: %d\n总游戏次数: %d",
                score, level, bestScore, totalGamesPlayed);
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("游戏结束")
                .setMessage(message)
                .setPositiveButton("再来一局", (dialog, which) -> {
                    gameView.startGame();
                    usageStore.recordLaunch(GAME_ID);
                })
                .setNegativeButton("返回大厅", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    private void showResumeDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("发现存档")
                .setMessage("检测到未完成的游戏，是否继续？")
                .setPositiveButton("继续游戏", (dialog, which) -> {
                    loadGameState();
                })
                .setNegativeButton("重新开始", (dialog, which) -> {
                    clearSaveData();
                    gameView.startGame();
                    usageStore.recordLaunch(GAME_ID);
                })
                .setCancelable(false)
                .show();
    }

    private void saveGameState() {
        try {
            JSONObject saveData = new JSONObject();
            saveData.put("score", currentScore);
            saveData.put("level", currentLevel);
            saveData.put("knivesLeft", gameView.isGameOver() ? 0 : 1);
            saveData.put("bestScore", bestScore);
            saveData.put("totalGames", totalGamesPlayed);
            saveData.put("totalApples", totalApplesHit);
            saveData.put("maxCombo", maxCombo);
            saveData.put("highestLevel", highestLevel);
            saveData.put("timestamp", System.currentTimeMillis());

            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_SAVE_DATA, saveData.toString())
                    .apply();
        } catch (JSONException e) {
            Log.e(TAG, "保存游戏状态失败", e);
        }
    }

    private void loadGameState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_SAVE_DATA, null);
        if (json == null) {
            gameView.startGame();
            return;
        }

        try {
            JSONObject saveData = new JSONObject(json);
            currentScore = saveData.optInt("score", 0);
            currentLevel = saveData.optInt("level", 1);
            bestScore = saveData.optInt("bestScore", 0);
            totalGamesPlayed = saveData.optInt("totalGames", 0);
            totalApplesHit = saveData.optInt("totalApples", 0);
            maxCombo = saveData.optInt("maxCombo", 0);
            highestLevel = saveData.optInt("highestLevel", 1);

            gameView.startGame();
        } catch (JSONException e) {
            Log.e(TAG, "加载游戏状态失败", e);
            gameView.startGame();
        }
    }

    private boolean hasSaveData() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_SAVE_DATA, null);
        if (json == null) return false;

        try {
            JSONObject saveData = new JSONObject(json);
            long timestamp = saveData.optLong("timestamp", 0);
            return (System.currentTimeMillis() - timestamp) < 24 * 60 * 60 * 1000;
        } catch (JSONException e) {
            return false;
        }
    }

    private void clearSaveData() {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_SAVE_DATA)
                .apply();
    }

    private void loadPersonalStats() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        bestScore = prefs.getInt("best_score", 0);
        totalGamesPlayed = prefs.getInt("total_games", 0);
        totalApplesHit = prefs.getInt("total_apples", 0);
        maxCombo = prefs.getInt("max_combo", 0);
        highestLevel = prefs.getInt("highest_level", 1);
    }

    private void savePersonalStats() {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt("best_score", bestScore)
                .putInt("total_games", totalGamesPlayed)
                .putInt("total_apples", totalApplesHit)
                .putInt("max_combo", maxCombo)
                .putInt("highest_level", highestLevel)
                .apply();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.pause();
        pauseBGM();
        if (!gameView.isGameOver() && !gameView.isLevelComplete()) {
            saveGameState();
        }
        savePersonalStats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameView.resume();
        playBGM();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gameView.destroy();
        if (soundPool != null) {
            soundPool.release();
        }
        if (bgmPlayer != null) {
            bgmPlayer.release();
        }
        savePersonalStats();
    }

    @Override
    public void onBackPressed() {
        if (isPaused) {
            togglePause();
            return;
        }
        if (!gameView.isGameOver() && !gameView.isLevelComplete()) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("退出游戏")
                    .setMessage("是否保存进度并退出？")
                    .setPositiveButton("保存并退出", (dialog, which) -> {
                        saveGameState();
                        savePersonalStats();
                        finish();
                    })
                    .setNegativeButton("直接退出", (dialog, which) -> {
                        clearSaveData();
                        finish();
                    })
                    .setNeutralButton("取消", null)
                    .show();
        } else {
            super.onBackPressed();
        }
    }
}
