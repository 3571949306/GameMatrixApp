package com.gamecenter.app.games.knife;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class KnifeGameView extends View {

    private static final String TAG = "KnifeGameView";

    private Paint bgPaint;
    private Paint targetPaint;
    private Paint targetBorderPaint;
    private Paint knifeHandlePaint;
    private Paint knifeBladePaint;
    private Paint knifeEdgePaint;
    private Paint textPaint;
    private Paint scorePaint;
    private Paint particlePaint;
    private Paint shadowPaint;
    private Paint glowPaint;
    private Paint woodRingPaint;
    private Paint applePaint;
    private Paint appleLeafPaint;

    private float centerX, centerY;
    private float targetRadius;
    private float targetRotation;
    private float rotationSpeed;
    private float knifeY;
    private boolean knifeFlying;
    private boolean knifeStuck;
    private float knifeStuckAngle;

    private List<StuckKnife> stuckKnives = new ArrayList<>();
    private List<Particle> particles = new ArrayList<>();
    private List<Sparkle> sparkles = new ArrayList<>();
    private List<Apple> apples = new ArrayList<>();

    private int score = 0;
    private int level = 1;
    private int knivesLeft = 8;
    private int totalKnives = 8;
    private boolean gameOver = false;
    private boolean levelComplete = false;
    private boolean paused = false;

    private Random random = new Random();
    private Handler animationHandler = new Handler(Looper.getMainLooper());
    private Runnable animationRunnable;

    private OnGameEventListener gameEventListener;

    private static final float KNIFE_SPEED = 22f;
    private static final float TARGET_BASE_RADIUS_DP = 85;
    private static final float KNIFE_LENGTH_DP = 65;
    private static final float KNIFE_WIDTH_DP = 10;
    private static final float HANDLE_LENGTH_DP = 28;

    private float knifeLength, knifeWidth, handleLength;

    private float targetPulsePhase = 0f;
    private float shakeOffsetX = 0f;
    private float shakeOffsetY = 0f;
    private int shakeFrames = 0;
    private float comboMultiplier = 1f;
    private int comboCount = 0;

    public KnifeGameView(Context context) {
        super(context);
        init();
    }

    public KnifeGameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;
        knifeLength = KNIFE_LENGTH_DP * density;
        knifeWidth = KNIFE_WIDTH_DP * density;
        handleLength = HANDLE_LENGTH_DP * density;

        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        targetPaint.setStyle(Paint.Style.FILL);

        targetBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        targetBorderPaint.setStyle(Paint.Style.STROKE);
        targetBorderPaint.setStrokeWidth(4 * density);
        targetBorderPaint.setColor(Color.parseColor("#2d2d2d"));

        knifeHandlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        knifeHandlePaint.setColor(Color.parseColor("#3d3d3d"));

        knifeBladePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        knifeBladePaint.setColor(Color.parseColor("#B8B8B8"));

        knifeEdgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        knifeEdgePaint.setColor(Color.parseColor("#F0F0F0"));

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(20 * density);
        textPaint.setTextAlign(Paint.Align.CENTER);

        scorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        scorePaint.setColor(Color.parseColor("#FFD700"));
        scorePaint.setTextSize(56 * density);
        scorePaint.setTextAlign(Paint.Align.CENTER);
        scorePaint.setShadowLayer(6 * density, 0, 3 * density, Color.parseColor("#B8860B"));

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadowPaint.setColor(Color.parseColor("#60000000"));

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        woodRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        woodRingPaint.setStyle(Paint.Style.STROKE);

        applePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        applePaint.setColor(Color.parseColor("#DC143C"));

        appleLeafPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        appleLeafPaint.setColor(Color.parseColor("#228B22"));

        animationRunnable = () -> {
            if (!paused) {
                update();
                invalidate();
            }
            animationHandler.postDelayed(animationRunnable, 16);
        };
        animationHandler.post(animationRunnable);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2f;
        centerY = h * 0.35f;
        float density = getResources().getDisplayMetrics().density;
        targetRadius = TARGET_BASE_RADIUS_DP * density;
        resetKnifePosition();
    }

    private void resetKnifePosition() {
        knifeY = getHeight() - 180;
        knifeFlying = false;
        knifeStuck = false;
    }

    public void startGame() {
        score = 0;
        level = 1;
        gameOver = false;
        levelComplete = false;
        stuckKnives.clear();
        particles.clear();
        sparkles.clear();
        apples.clear();
        comboCount = 0;
        comboMultiplier = 1f;
        setupLevel();
        resetKnifePosition();
        invalidate();
    }

    public void setupLevel() {
        totalKnives = 5 + level * 2;
        if (level > 8) totalKnives = 20;
        knivesLeft = totalKnives;
        stuckKnives.clear();
        apples.clear();
        targetRotation = random.nextFloat() * 360;
        rotationSpeed = 1.2f + level * 0.35f;
        if (level > 3) {
            rotationSpeed += random.nextFloat() * 1.2f;
        }
        if (level > 6) {
            rotationSpeed = 1.8f + random.nextFloat() * 2.5f;
        }
        if (level > 10) {
            rotationSpeed = 2.5f + random.nextFloat() * 3f;
        }

        int appleCount = Math.min(level / 2, 4);
        for (int i = 0; i < appleCount; i++) {
            float angle = random.nextFloat() * 360;
            apples.add(new Apple(angle, targetRadius + knifeLength * 0.6f));
        }

        levelComplete = false;
        resetKnifePosition();
    }

    private void update() {
        if (gameOver || levelComplete) return;

        targetRotation += rotationSpeed;
        if (targetRotation >= 360) targetRotation -= 360;
        if (targetRotation < 0) targetRotation += 360;

        targetPulsePhase += 0.04f;

        if (shakeFrames > 0) {
            shakeFrames--;
            shakeOffsetX = (random.nextFloat() - 0.5f) * 12;
            shakeOffsetY = (random.nextFloat() - 0.5f) * 12;
        } else {
            shakeOffsetX = 0;
            shakeOffsetY = 0;
        }

        if (knifeFlying) {
            knifeY -= KNIFE_SPEED * getResources().getDisplayMetrics().density;
            float hitY = centerY + targetRadius + knifeLength * 0.3f;
            if (knifeY <= hitY) {
                knifeFlying = false;
                checkHit();
            }
        }

        updateParticles();
    }

    private void checkHit() {
        float hitAngle = 90;
        float effectiveAngle = (hitAngle - targetRotation + 360) % 360;

        for (StuckKnife stuck : stuckKnives) {
            float diff = Math.abs(effectiveAngle - stuck.angle);
            if (diff > 180) diff = 360 - diff;
            if (diff < 12f) {
                triggerGameOver();
                return;
            }
        }

        Iterator<Apple> appleIter = apples.iterator();
        boolean hitApple = false;
        while (appleIter.hasNext()) {
            Apple apple = appleIter.next();
            float appleScreenAngle = (apple.angle + targetRotation) % 360;
            float diff = Math.abs(hitAngle - appleScreenAngle);
            if (diff > 180) diff = 360 - diff;
            if (diff < 15f) {
                hitApple = true;
                appleIter.remove();
                spawnAppleParticles(apple);
                score += (int)(50 * comboMultiplier);
                comboCount++;
                comboMultiplier = Math.min(1f + comboCount * 0.2f, 5f);
                spawnSparkles(centerX + (float)Math.cos(Math.toRadians(appleScreenAngle)) * apple.distance,
                        centerY + (float)Math.sin(Math.toRadians(appleScreenAngle)) * apple.distance);
                break;
            }
        }

        if (!hitApple) {
            score += (int)(10 * comboMultiplier);
            comboCount++;
            comboMultiplier = Math.min(1f + comboCount * 0.1f, 3f);
        }

        stuckKnives.add(new StuckKnife(effectiveAngle, knifeLength));
        spawnHitParticles();
        shakeFrames = 5;

        knivesLeft--;

        if (knivesLeft <= 0) {
            levelComplete = true;
            score += level * 100;
            comboCount = 0;
            comboMultiplier = 1f;
            spawnLevelCompleteParticles();
            if (gameEventListener != null) {
                gameEventListener.onLevelComplete(level, score);
            }
        } else {
            resetKnifePosition();
        }

        if (gameEventListener != null) {
            gameEventListener.onScoreChanged(score);
            gameEventListener.onKnivesChanged(knivesLeft, totalKnives);
        }
    }

    private void triggerGameOver() {
        gameOver = true;
        shakeFrames = 20;
        spawnGameOverParticles();
        comboCount = 0;
        comboMultiplier = 1f;
        if (gameEventListener != null) {
            gameEventListener.onGameOver(score, level);
        }
    }

    public void throwKnife() {
        if (gameOver || levelComplete || knifeFlying || knifeStuck) return;
        knifeFlying = true;
    }

    public void nextLevel() {
        if (levelComplete) {
            level++;
            setupLevel();
        }
    }

    private void updateParticles() {
        Iterator<Particle> iter = particles.iterator();
        while (iter.hasNext()) {
            Particle p = iter.next();
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.3f;
            p.life -= 0.02f;
            p.alpha = (int)(255 * Math.max(0, p.life));
            if (p.life <= 0) iter.remove();
        }

        Iterator<Sparkle> sIter = sparkles.iterator();
        while (sIter.hasNext()) {
            Sparkle s = sIter.next();
            s.x += s.vx;
            s.y += s.vy;
            s.life -= 0.03f;
            s.alpha = (int)(255 * Math.max(0, s.life));
            if (s.life <= 0) sIter.remove();
        }
    }

    private void spawnHitParticles() {
        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 15; i++) {
            float angle = (float)(random.nextFloat() * Math.PI);
            float speed = 2 + random.nextFloat() * 6;
            particles.add(new Particle(
                    centerX + (float)Math.cos(angle) * targetRadius,
                    centerY + targetRadius + (float)Math.sin(angle) * 10,
                    (float)Math.cos(angle) * speed * density,
                    -(2 + random.nextFloat() * 4) * density,
                    Color.parseColor("#DEB887"),
                    0.8f + random.nextFloat() * 0.5f,
                    3 + random.nextFloat() * 5 * density
            ));
        }
        for (int i = 0; i < 8; i++) {
            float angle = (float)(random.nextFloat() * Math.PI);
            float speed = 1 + random.nextFloat() * 4;
            particles.add(new Particle(
                    centerX + (float)Math.cos(angle) * targetRadius,
                    centerY + targetRadius,
                    (float)Math.cos(angle) * speed * density,
                    -(1 + random.nextFloat() * 3) * density,
                    Color.parseColor("#8B4513"),
                    0.6f + random.nextFloat() * 0.4f,
                    2 + random.nextFloat() * 4 * density
            ));
        }
    }

    private void spawnAppleParticles(Apple apple) {
        float density = getResources().getDisplayMetrics().density;
        float ax = centerX + (float)Math.cos(Math.toRadians(apple.angle)) * apple.distance;
        float ay = centerY + (float)Math.sin(Math.toRadians(apple.angle)) * apple.distance;
        for (int i = 0; i < 20; i++) {
            float angle = (float)(random.nextFloat() * Math.PI * 2);
            float speed = 3 + random.nextFloat() * 7;
            particles.add(new Particle(
                    ax, ay,
                    (float)Math.cos(angle) * speed * density,
                    (float)Math.sin(angle) * speed * density,
                    Color.parseColor(i % 2 == 0 ? "#DC143C" : "#228B22"),
                    1f + random.nextFloat() * 0.5f,
                    4 + random.nextFloat() * 6 * density
            ));
        }
    }

    private void spawnLevelCompleteParticles() {
        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 50; i++) {
            float angle = (float)(random.nextFloat() * Math.PI * 2);
            float speed = 2 + random.nextFloat() * 8;
            int[] colors = {Color.parseColor("#FFD700"), Color.parseColor("#FF6347"), Color.parseColor("#00CED1"), Color.parseColor("#FF69B4")};
            particles.add(new Particle(
                    centerX, centerY,
                    (float)Math.cos(angle) * speed * density,
                    (float)Math.sin(angle) * speed * density,
                    colors[random.nextInt(colors.length)],
                    1.5f + random.nextFloat() * 1f,
                    4 + random.nextFloat() * 8 * density
            ));
        }
    }

    private void spawnGameOverParticles() {
        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 30; i++) {
            float angle = (float)(random.nextFloat() * Math.PI * 2);
            float speed = 3 + random.nextFloat() * 6;
            particles.add(new Particle(
                    centerX, centerY,
                    (float)Math.cos(angle) * speed * density,
                    (float)Math.sin(angle) * speed * density,
                    Color.parseColor("#FF4444"),
                    1f + random.nextFloat() * 0.8f,
                    4 + random.nextFloat() * 6 * density
            ));
        }
    }

    private void spawnSparkles(float x, float y) {
        for (int i = 0; i < 10; i++) {
            float angle = (float)(random.nextFloat() * Math.PI * 2);
            float speed = 1 + random.nextFloat() * 3;
            sparkles.add(new Sparkle(
                    x, y,
                    (float)Math.cos(angle) * speed,
                    (float)Math.sin(angle) * speed,
                    1f + random.nextFloat() * 0.5f
            ));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        drawBackground(canvas);

        canvas.save();
        canvas.translate(shakeOffsetX, shakeOffsetY);

        drawTarget(canvas);
        drawStuckKnives(canvas);
        drawApples(canvas);

        canvas.restore();

        drawFlyingKnife(canvas);
        drawUI(canvas);
        drawParticles(canvas);
        drawSparkles(canvas);

        if (gameOver) {
            drawGameOverOverlay(canvas);
        } else if (levelComplete) {
            drawLevelCompleteOverlay(canvas);
        }
    }

    private void drawBackground(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();

        LinearGradient bgGradient = new LinearGradient(
                0, 0, 0, h,
                Color.parseColor("#0f0f23"),
                Color.parseColor("#1a1a3e"),
                Shader.TileMode.CLAMP);
        bgPaint.setShader(bgGradient);
        canvas.drawRect(0, 0, w, h, bgPaint);

        for (int i = 0; i < 30; i++) {
            float x = (i * 137.5f) % w;
            float y = (i * 89.3f) % h;
            float alpha = 30 + (i * 7) % 60;
            particlePaint.setColor(Color.argb((int)alpha, 255, 255, 255));
            canvas.drawCircle(x, y, 1 + (i % 3), particlePaint);
        }
    }

    private void drawTarget(Canvas canvas) {
        float pulse = (float)(Math.sin(targetPulsePhase) * 0.02f + 1f);
        float r = targetRadius * pulse;

        float shadowR = r + 8;
        RadialGradient shadowGrad = new RadialGradient(
                centerX, centerY + 10, shadowR,
                Color.parseColor("#40000000"), Color.TRANSPARENT,
                Shader.TileMode.CLAMP);
        shadowPaint.setShader(shadowGrad);
        canvas.drawCircle(centerX, centerY + 10, shadowR, shadowPaint);

        int[] ringColors = {
                Color.parseColor("#8B4513"),
                Color.parseColor("#A0522D"),
                Color.parseColor("#CD853F"),
                Color.parseColor("#8B4513"),
                Color.parseColor("#A0522D"),
                Color.parseColor("#DEB887")
        };

        float[] ringRadii = {1.0f, 0.82f, 0.65f, 0.48f, 0.32f, 0.18f};

        for (int i = 0; i < ringColors.length; i++) {
            float ringR = r * ringRadii[i];
            targetPaint.setColor(ringColors[i]);
            canvas.drawCircle(centerX, centerY, ringR, targetPaint);

            if (i < ringColors.length - 1) {
                woodRingPaint.setColor(Color.parseColor("#5D3A1A"));
                woodRingPaint.setStrokeWidth(2);
                canvas.drawCircle(centerX, centerY, ringR, woodRingPaint);
            }
        }

        targetPaint.setColor(Color.parseColor("#FFD700"));
        canvas.drawCircle(centerX, centerY, r * 0.08f, targetPaint);

        targetPaint.setColor(Color.parseColor("#B8860B"));
        canvas.drawCircle(centerX, centerY, r * 0.05f, targetPaint);

        canvas.drawCircle(centerX, centerY, r, targetBorderPaint);
    }

    private void drawStuckKnives(Canvas canvas) {
        for (StuckKnife stuck : stuckKnives) {
            float angleRad = (float)Math.toRadians(stuck.angle + targetRotation);
            float knifeX = centerX + (float)Math.cos(angleRad) * (targetRadius + knifeLength * 0.4f);
            float knifeY = centerY + (float)Math.sin(angleRad) * (targetRadius + knifeLength * 0.4f);
            float knifeAngle = stuck.angle + targetRotation + 90;

            canvas.save();
            canvas.translate(knifeX, knifeY);
            canvas.rotate(knifeAngle);
            drawKnifeGraphic(canvas, 0, 0);
            canvas.restore();
        }
    }

    private void drawApples(Canvas canvas) {
        for (Apple apple : apples) {
            float angleRad = (float)Math.toRadians(apple.angle + targetRotation);
            float ax = centerX + (float)Math.cos(angleRad) * apple.distance;
            float ay = centerY + (float)Math.sin(angleRad) * apple.distance;

            float appleSize = 12 * getResources().getDisplayMetrics().density;

            canvas.drawCircle(ax, ay, appleSize, applePaint);

            float leafX = ax + appleSize * 0.3f;
            float leafY = ay - appleSize * 0.8f;
            canvas.drawOval(leafX - appleSize * 0.4f, leafY - appleSize * 0.2f,
                    leafX + appleSize * 0.4f, leafY + appleSize * 0.2f, appleLeafPaint);

            targetPaint.setColor(Color.parseColor("#8B0000"));
            canvas.drawCircle(ax - appleSize * 0.2f, ay - appleSize * 0.2f, appleSize * 0.15f, targetPaint);
        }
    }

    private void drawFlyingKnife(Canvas canvas) {
        if (knifeFlying || (!gameOver && !levelComplete)) {
            float drawY = knifeFlying ? knifeY : getHeight() - 180;
            canvas.save();
            canvas.translate(centerX, drawY);
            drawKnifeGraphic(canvas, 0, 0);
            canvas.restore();
        }
    }

    private void drawKnifeGraphic(Canvas canvas, float x, float y) {
        float density = getResources().getDisplayMetrics().density;

        float hL = handleLength;
        float bL = knifeLength - hL;
        float w = knifeWidth;
        float hw = w / 2;

        Path bladePath = new Path();
        bladePath.moveTo(x - hw, y - bL);
        bladePath.lineTo(x + hw, y - bL);
        bladePath.lineTo(x + hw * 0.3f, y);
        bladePath.lineTo(x - hw * 0.3f, y);
        bladePath.close();
        canvas.drawPath(bladePath, knifeBladePaint);

        canvas.drawLine(x - hw, y - bL, x, y - bL - hw * 1.5f, knifeEdgePaint);
        canvas.drawLine(x + hw, y - bL, x, y - bL - hw * 1.5f, knifeEdgePaint);

        RectF handleRect = new RectF(x - hw * 1.2f, y, x + hw * 1.2f, y + hL);
        canvas.drawRoundRect(handleRect, 4 * density, 4 * density, knifeHandlePaint);

        targetPaint.setColor(Color.parseColor("#666666"));
        for (int i = 0; i < 3; i++) {
            float ringY = y + hL * 0.3f + i * hL * 0.2f;
            canvas.drawLine(x - hw * 0.8f, ringY, x + hw * 0.8f, ringY, targetPaint);
        }
    }

    private void drawUI(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        int w = getWidth();

        canvas.drawText("" + score, w / 2f, 80 * density, scorePaint);

        textPaint.setTextSize(16 * density);
        textPaint.setColor(Color.parseColor("#AAAAAA"));
        canvas.drawText("第 " + level + " 关", w / 2f, 110 * density, textPaint);

        if (comboCount > 1) {
            textPaint.setTextSize(24 * density);
            textPaint.setColor(Color.parseColor("#FF6347"));
            canvas.drawText(comboCount + " 连击! x" + String.format("%.1f", comboMultiplier), w / 2f, 140 * density, textPaint);
        }

        float knifeIconSize = 16 * density;
        float startX = w / 2f - (totalKnives * knifeIconSize * 1.5f) / 2;
        float knifeY = getHeight() - 100;
        for (int i = 0; i < totalKnives; i++) {
            float kx = startX + i * knifeIconSize * 1.5f;
            if (i < knivesLeft) {
                knifeBladePaint.setColor(Color.parseColor("#C0C0C0"));
            } else {
                knifeBladePaint.setColor(Color.parseColor("#444444"));
            }
            canvas.drawRect(kx - 2, knifeY - knifeIconSize, kx + 2, knifeY, knifeBladePaint);
            canvas.drawRect(kx - 3, knifeY, kx + 3, knifeY + knifeIconSize * 0.6f, knifeHandlePaint);
        }
    }

    private void drawParticles(Canvas canvas) {
        for (Particle p : particles) {
            particlePaint.setColor(p.color);
            particlePaint.setAlpha(p.alpha);
            canvas.drawCircle(p.x, p.y, p.size, particlePaint);
        }
        particlePaint.setAlpha(255);
    }

    private void drawSparkles(Canvas canvas) {
        for (Sparkle s : sparkles) {
            glowPaint.setColor(Color.argb(s.alpha, 255, 215, 0));
            canvas.drawCircle(s.x, s.y, 3, glowPaint);
        }
    }

    private void drawGameOverOverlay(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float density = getResources().getDisplayMetrics().density;

        targetPaint.setColor(Color.argb(180, 0, 0, 0));
        canvas.drawRect(0, 0, w, h, targetPaint);

        textPaint.setTextSize(48 * density);
        textPaint.setColor(Color.parseColor("#FF4444"));
        canvas.drawText("游戏结束", w / 2f, h / 2f - 60 * density, textPaint);

        textPaint.setTextSize(28 * density);
        textPaint.setColor(Color.WHITE);
        canvas.drawText("最终得分: " + score, w / 2f, h / 2f, textPaint);
        canvas.drawText("到达第 " + level + " 关", w / 2f, h / 2f + 40 * density, textPaint);

        textPaint.setTextSize(18 * density);
        textPaint.setColor(Color.parseColor("#AAAAAA"));
        canvas.drawText("点击屏幕重新开始", w / 2f, h / 2f + 100 * density, textPaint);
    }

    private void drawLevelCompleteOverlay(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        float density = getResources().getDisplayMetrics().density;

        targetPaint.setColor(Color.argb(120, 0, 0, 0));
        canvas.drawRect(0, 0, w, h, targetPaint);

        textPaint.setTextSize(42 * density);
        textPaint.setColor(Color.parseColor("#FFD700"));
        canvas.drawText("过关!", w / 2f, h / 2f - 40 * density, textPaint);

        textPaint.setTextSize(24 * density);
        textPaint.setColor(Color.WHITE);
        canvas.drawText("得分: " + score, w / 2f, h / 2f + 10 * density, textPaint);

        textPaint.setTextSize(18 * density);
        textPaint.setColor(Color.parseColor("#AAAAAA"));
        canvas.drawText("点击屏幕进入下一关", w / 2f, h / 2f + 60 * density, textPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (gameOver) {
                startGame();
                return true;
            }
            if (levelComplete) {
                nextLevel();
                return true;
            }
            throwKnife();
            return true;
        }
        return super.onTouchEvent(event);
    }

    public void setOnGameEventListener(OnGameEventListener listener) {
        this.gameEventListener = listener;
    }

    public int getScore() { return score; }
    public int getLevel() { return level; }
    public boolean isGameOver() { return gameOver; }
    public boolean isLevelComplete() { return levelComplete; }

    public void pause() {
        paused = true;
    }

    public void resume() {
        paused = false;
    }

    public void destroy() {
        animationHandler.removeCallbacks(animationRunnable);
    }

    private static class StuckKnife {
        float angle;
        float length;
        StuckKnife(float angle, float length) {
            this.angle = angle;
            this.length = length;
        }
    }

    private static class Particle {
        float x, y, vx, vy, life, size;
        int color, alpha;
        Particle(float x, float y, float vx, float vy, int color, float life, float size) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.color = color; this.life = life; this.size = size;
            this.alpha = 255;
        }
    }

    private static class Sparkle {
        float x, y, vx, vy, life;
        int alpha;
        Sparkle(float x, float y, float vx, float vy, float life) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.life = life; this.alpha = 255;
        }
    }

    private static class Apple {
        float angle;
        float distance;
        Apple(float angle, float distance) {
            this.angle = angle;
            this.distance = distance;
        }
    }

    public interface OnGameEventListener {
        void onScoreChanged(int score);
        void onKnivesChanged(int left, int total);
        void onLevelComplete(int level, int score);
        void onGameOver(int score, int level);
    }
}
